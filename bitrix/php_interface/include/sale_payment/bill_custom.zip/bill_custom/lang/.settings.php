<?php
return [
	'*' => [
		'languages' => [
			'ru',
			'en',
		],
	],
];

<?php
return [
	'*' => [
		'languages' => [
			'ru',
		],
	],
];
